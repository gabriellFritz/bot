# Cyberspace bot

#This source serves as a base for Cyberspace store bots.
#It aims to be as modular as possible, allowing adding new features with minor effort.

## Example config file

# Your Telegram bot token.
BOT_TOKEN = "5146267383:AAEN6Ahlc5Il7ZK29hJsuOqB3fKLQ-blaIA"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
# API_ID = 611335
# API_HASH = "d524b414d21f4d37f08684c1df41ac9c"
API_ID = 11989670
API_HASH = "b55182231af29c5ab4d79af384ac7336"

# Chat used for logging errors.
LOG_CHAT = -1001510894267

# Chat used for logging user actions (like buy, gift, etc).
ADMIN_CHAT = -1001510894267

# How many updates can be handled in parallel.
# Don't use high values for low-end servers.
WORKERS = 20

# Admins can access panel and add new materials to the bot.
ADMINS = [1099990200]

# Sudoers have full access to the server and can execute commands.
SUDOERS = [1099990200]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = []
#
