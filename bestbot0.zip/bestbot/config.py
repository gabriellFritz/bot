# Bot token.
BOT_TOKEN = "5146267383:AAEN6Ahlc5Il7ZK29hJsuOqB3fKLQ-blaIA"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
API_ID = 10079278
API_HASH = "4b3081d2d4c57095d0fdbe4077ad20b9"

# CHAT DE ERROS
LOG_CHAT = -1001510894267

# LOGS DE COMPRAS E ADD SALDO
ADMIN_CHAT = -1001510894267

# CHAT DE COMPRAS PARA CLIENTE
CLIENT_CHAT = -1001510894267
# Quantas atualiza��es podem ser tratadas em paralelo.
# N�o use valores altos para servidores low-end.
WORKERS = 20

# Os administradores podem acessar o painel e adicionar novos materiais ao bot.
ADMINS = [1099990200, 1099990200]

# Sudoers t�m acesso total ao servidor e podem executar comandos.
SUDOERS = [1099990200]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = []
